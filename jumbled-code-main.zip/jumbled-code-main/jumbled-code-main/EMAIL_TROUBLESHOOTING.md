# Email Troubleshooting Guide

## Quick Diagnosis

Run this command to test your email configuration:
```bash
node test-email.js
```

This will show you exactly what's missing or misconfigured.

## Common Issues and Solutions

### 1. Missing .env File

**Problem**: No `.env` file in your project directory.

**Solution**: Create a `.env` file in the `jumbled-code-main/` directory:

```env
# MongoDB Connection
MONGO_URI=mongodb://localhost:27017/jumbled-code

# JWT Secret for password reset tokens
JWT_SECRET=your-generated-jwt-secret-here

# Email Configuration (Gmail)
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-16-character-app-password

# Base URL for password reset links
BASE_URL=http://localhost:5000

# Server Port
PORT=5000
```

### 2. Incorrect Email Credentials

**Problem**: Wrong email or password in `.env` file.

**Solution**: 
1. Make sure `EMAIL_USER` is your complete Gmail address
2. Make sure `EMAIL_PASS` is an **app password**, not your regular Gmail password

### 3. Missing App Password

**Problem**: Using regular Gmail password instead of app password.

**Solution**: Generate an app password:
1. Go to https://myaccount.google.com/
2. Navigate to "Security" → "2-Step Verification" → "App passwords"
3. Select "Mail" and "Other"
4. Generate the 16-character password
5. Use this password in your `.env` file

### 4. 2-Step Verification Not Enabled

**Problem**: Can't generate app password because 2-Step Verification is disabled.

**Solution**: Enable 2-Step Verification first:
1. Go to https://myaccount.google.com/
2. Navigate to "Security" → "2-Step Verification"
3. Follow the setup process
4. Then generate an app password

### 5. Gmail Security Settings

**Problem**: Gmail blocking the connection.

**Solution**: 
1. Make sure "Less secure app access" is enabled (if not using app passwords)
2. Or use app passwords (recommended)
3. Check if your Gmail account has any security restrictions

### 6. Network/Firewall Issues

**Problem**: Connection to Gmail servers blocked.

**Solution**:
1. Check your internet connection
2. Disable firewall temporarily for testing
3. Try from a different network

## Step-by-Step Setup

### Step 1: Generate JWT Secret
```bash
node generate-secret.js
```

### Step 2: Create .env File
Create a file named `.env` in your `jumbled-code-main/` directory with:
```env
JWT_SECRET=your-generated-secret-here
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
BASE_URL=http://localhost:5000
PORT=5000
```

### Step 3: Test Email Configuration
```bash
node test-email.js
```

### Step 4: Start Server
```bash
node server.js
```

### Step 5: Test Password Reset
1. Go to http://localhost:5000/forgot-password.html
2. Enter a registered email address
3. Check if you receive the reset email

## Debugging Steps

### 1. Check Console Logs
When you try to reset a password, look for these log messages:
- `🔍 Looking for user with email: [email]`
- `✅ User found: [email]`
- `✅ Reset token generated and saved`
- `🔗 Reset link created: [link]`
- `📧 Attempting to send email to: [email]`
- `✅ Password reset email sent successfully to: [email]`

### 2. Check for Error Messages
Common error messages and solutions:
- `Email service not configured`: Missing .env file or email variables
- `Email authentication failed`: Wrong email/password or missing app password
- `Email connection failed`: Network or Gmail server issues

### 3. Verify Environment Variables
Run this to check if variables are loaded:
```bash
node -e "require('dotenv').config(); console.log('EMAIL_USER:', process.env.EMAIL_USER); console.log('EMAIL_PASS:', process.env.EMAIL_PASS ? 'Set' : 'Missing');"
```

## Testing Without Real Email

If you want to test the functionality without sending real emails, you can:

1. **Use a test email service** like Mailtrap
2. **Modify the code** to log the email content instead of sending
3. **Use a development email service** like Ethereal Email

## Production Considerations

For production deployment:
1. Use a proper email service (SendGrid, AWS SES, etc.)
2. Set up proper domain and SSL certificates
3. Use environment variables from your hosting platform
4. Configure proper CORS settings
5. Set up monitoring and logging

## Still Having Issues?

If you're still experiencing problems:

1. **Check the console output** when running `node test-email.js`
2. **Verify your Gmail settings** are correct
3. **Try with a different Gmail account** for testing
4. **Check if your Gmail account has any restrictions**
5. **Ensure you're using the latest version** of nodemailer

## Support

If none of the above solutions work, please:
1. Run `node test-email.js` and share the output
2. Check the server console logs when attempting password reset
3. Verify your .env file contents (without sharing sensitive data)
4. Confirm your Gmail account settings
