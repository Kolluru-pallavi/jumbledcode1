require('dotenv').config();
const nodemailer = require('nodemailer');

console.log('🔍 Testing Email Configuration...\n');

// Check environment variables
const emailUser = process.env.EMAIL_USER;
const emailPass = process.env.EMAIL_PASS;
const jwtSecret = process.env.JWT_SECRET;
const baseUrl = process.env.BASE_URL;
const port = process.env.PORT;

console.log('📋 Environment Variables Check:');
console.log('   EMAIL_USER:', emailUser ? '✅ Set' : '❌ Missing');
console.log('   EMAIL_PASS:', emailPass ? '✅ Set' : '❌ Missing');
console.log('   JWT_SECRET:', jwtSecret ? '✅ Set' : '❌ Missing');
console.log('   BASE_URL:', baseUrl ? '✅ Set' : '❌ Missing (will use default)');
console.log('   PORT:', port ? '✅ Set' : '❌ Missing (will use default 5000)');

if (!emailUser || !emailPass) {
    console.log('\n❌ Email configuration is incomplete!');
    console.log('   Please create a .env file with the following variables:');
    console.log('   EMAIL_USER=your-email@gmail.com');
    console.log('   EMAIL_PASS=your-app-password');
    console.log('   JWT_SECRET=your-jwt-secret');
    console.log('   BASE_URL=http://localhost:5000');
    process.exit(1);
}

// Test email transporter
async function testEmail() {
    try {
        console.log('\n📧 Testing email transporter...');
        
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: emailUser,
                pass: emailPass
            }
        });

        // Verify transporter
        await transporter.verify();
        console.log('✅ Email transporter verified successfully!');

        // Test email (optional - uncomment to send a test email)
        /*
        const testMailOptions = {
            from: emailUser,
            to: emailUser, // Send to yourself for testing
            subject: 'Test Email - Jumbled Code',
            html: `
                <h2>Test Email</h2>
                <p>This is a test email to verify your email configuration is working.</p>
                <p>If you receive this email, your password reset functionality should work!</p>
            `
        };

        console.log('📤 Sending test email...');
        await transporter.sendMail(testMailOptions);
        console.log('✅ Test email sent successfully!');
        */

        console.log('\n🎉 Email configuration is working correctly!');
        console.log('   Your password reset functionality should work now.');
        
    } catch (error) {
        console.error('\n❌ Email test failed:', error.message);
        
        if (error.code === 'EAUTH') {
            console.log('\n🔧 Troubleshooting tips:');
            console.log('   1. Make sure your EMAIL_USER is correct');
            console.log('   2. Make sure your EMAIL_PASS is an app password (not your regular password)');
            console.log('   3. Enable 2-Step Verification on your Google account');
            console.log('   4. Generate an app password: https://myaccount.google.com/apppasswords');
        } else if (error.code === 'ECONNECTION') {
            console.log('\n🔧 Troubleshooting tips:');
            console.log('   1. Check your internet connection');
            console.log('   2. Make sure Gmail is accessible');
            console.log('   3. Try again in a few minutes');
        }
    }
}

testEmail();
