# Email Setup for Password Reset Functionality

## Prerequisites

1. **Gmail Account**: You need a Gmail account to send emails
2. **App Password**: You need to generate an app password for your Gmail account

## Step 1: Generate Gmail App Password

1. Go to your Google Account settings: https://myaccount.google.com/
2. Navigate to "Security" tab
3. Enable "2-Step Verification" if not already enabled
4. Go to "App passwords" (under 2-Step Verification)
5. Select "Mail" as the app and "Other" as the device
6. Generate the app password
7. Copy the generated 16-character password

## Step 2: Create Environment Variables

Create a `.env` file in the root directory (`jumbled-code-main/`) with the following variables:

```env
# MongoDB Connection
MONGO_URI=mongodb://localhost:27017/jumbled-code

# JWT Secret for password reset tokens
JWT_SECRET=your-super-secret-jwt-key-here

# Email Configuration (Gmail)
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-16-character-app-password

# Base URL for password reset links
BASE_URL=http://localhost:5000

# Server Port
PORT=5000
```

## Step 3: Replace Placeholder Values

- Replace `your-email@gmail.com` with your actual Gmail address
- Replace `your-16-character-app-password` with the app password generated in Step 1
- Replace `your-super-secret-jwt-key-here` with a strong secret key
- Update `BASE_URL` if your application runs on a different URL

## Step 4: Test the Setup

1. Start your server: `npm start` or `node server.js`
2. Navigate to the forgot password page
3. Enter a registered email address
4. Check if the reset email is received

## Troubleshooting

### Email Not Sending

1. **Check environment variables**: Make sure all required variables are set in `.env`
2. **Verify Gmail credentials**: Ensure the email and app password are correct
3. **Check console logs**: Look for error messages in the server console
4. **Gmail security**: Make sure "Less secure app access" is enabled or use app passwords

### Common Errors

- `Invalid login`: Check your email and app password
- `User not found`: Make sure the email is registered in your database
- `Token expired`: The reset link expires after 15 minutes

## Security Notes

1. Never commit your `.env` file to version control
2. Use strong, unique JWT secrets
3. Regularly rotate your app passwords
4. Consider using environment-specific configurations for production

## Production Deployment

For production deployment:

1. Use a proper email service (SendGrid, AWS SES, etc.)
2. Set up proper domain and SSL certificates
3. Use environment variables from your hosting platform
4. Configure proper CORS settings
5. Set up monitoring and logging
