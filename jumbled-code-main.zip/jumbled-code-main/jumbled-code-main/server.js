require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(express.static(__dirname)); // Serve static HTML/CSS/JS

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.error('MongoDB connection error:', err));

// Import User model
const User = require('./models/User');

// Import auth routes
const authRoutes = require('./routes/auth');
app.use('/api', authRoutes);

// Route: Root '/' redirects to home.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
});

// API: Register User
app.post('/api/register', async (req, res) => {
    const { username, email, password } = req.body;
    console.log('Registration Attempt:', email);

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            console.log('Email already registered:', email);
            return res.status(400).json({ error: 'Email already registered' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        console.log('User registered successfully:', email);
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Server error during registration' });
    }
});

// API: Login User
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    console.log('Login Attempt:', email);

    try {
        const user = await User.findOne({ email });
        if (!user) {
            console.log('User not found:', email);
            return res.status(400).json({ error: 'User not found' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            console.log('Invalid password for:', email);
            return res.status(400).json({ error: 'Invalid password' });
        }

        console.log('Login successful for:', email);
        res.status(200).json({ message: 'Login successful', username: user.username, email: user.email });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Server error during login' });
    }
});

// API: Get User by Email (basic, unauthenticated demo)
app.get('/api/user', async (req, res) => {
    try {
        const { email } = req.query;
        if (!email) {
            return res.status(400).json({ error: 'Email is required' });
        }
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        return res.json({ username: user.username, email: user.email });
    } catch (error) {
        console.error('Get user error:', error);
        return res.status(500).json({ error: 'Server error fetching user' });
    }
});

// API: Update User Details (basic, unauthenticated demo)
app.put('/api/user', async (req, res) => {
    try {
        const { email, newUsername, newEmail, newPassword } = req.body;
        if (!email) {
            return res.status(400).json({ error: 'Current email is required' });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (newUsername && newUsername.trim()) {
            user.username = newUsername.trim();
        }

        // Ignore newEmail if provided: email updates are not allowed here

        if (newPassword && newPassword.length >= 6) {
            user.password = await bcrypt.hash(newPassword, 10);
        }

        await user.save();
        return res.json({ message: 'User updated successfully', username: user.username, email: user.email });
    } catch (error) {
        console.error('Update user error:', error);
        return res.status(500).json({ error: 'Server error during user update' });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});