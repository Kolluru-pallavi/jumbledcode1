const crypto = require('crypto');

// Generate a secure JWT secret
const secret = crypto.randomBytes(64).toString('hex');

console.log('🔐 Your JWT Secret Key:');
console.log('='.repeat(50));
console.log(secret);
console.log('='.repeat(50));
console.log('\n📝 Copy this secret and add it to your .env file:');
console.log('JWT_SECRET=' + secret);
console.log('\n⚠️  Important: Keep this secret secure and never commit it to version control!');
