require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

console.log('🔍 Testing Password Reset Functionality...\n');

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('✅ MongoDB Connected'))
    .catch(err => console.error('❌ MongoDB connection error:', err));

async function testPasswordReset() {
    try {
        // Check if there are any users in the database
        const users = await User.find({});
        console.log(`📊 Found ${users.length} users in database`);
        
        if (users.length === 0) {
            console.log('❌ No users found in database');
            console.log('   Please register a user first before testing password reset');
            return;
        }

        // Get the first user for testing
        const testUser = users[0];
        console.log('🧪 Testing with user:', testUser.email);

        // Test the forgot password functionality
        const { email } = testUser;
        
        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            console.log('❌ User not found:', email);
            return;
        }

        console.log('✅ User found:', user.email);

        // Generate a test token
        const jwt = require('jsonwebtoken');
        const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
        
        const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '15m' });
        user.resetToken = token;
        user.resetTokenExpiry = new Date(Date.now() + 15 * 60 * 1000); // 15 mins
        await user.save();

        console.log('✅ Reset token generated and saved');

        // Create reset link
        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5000}`;
        const resetLink = `${baseUrl}/reset-password.html?token=${token}`;

        console.log('🔗 Reset link created:', resetLink);

        // Test email sending
        const nodemailer = require('nodemailer');
        
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });

        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: user.email,
            subject: 'Password Reset Test - Jumbled Code',
            html: `
                <h2>Password Reset Test</h2>
                <p>This is a test email for password reset functionality.</p>
                <p>Click the link below to test the reset password page:</p>
                <a href="${resetLink}" style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Test Reset Password</a>
                <p>This link will expire in 15 minutes.</p>
                <p><strong>Test Details:</strong></p>
                <ul>
                    <li>User: ${user.email}</li>
                    <li>Token: ${token.substring(0, 20)}...</li>
                    <li>Expires: ${new Date(user.resetTokenExpiry).toLocaleString()}</li>
                </ul>
            `
        };

        console.log('📧 Sending test password reset email...');
        await transporter.sendMail(mailOptions);
        console.log('✅ Test password reset email sent successfully!');
        
        console.log('\n🎉 Password reset functionality test completed!');
        console.log('   Check your email for the test reset link.');
        console.log('   You can also manually test by visiting:');
        console.log('   http://localhost:5000/forgot-password.html');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        mongoose.connection.close();
    }
}

testPasswordReset();
