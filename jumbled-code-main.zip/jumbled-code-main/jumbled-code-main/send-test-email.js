require('dotenv').config();
const nodemailer = require('nodemailer');

console.log('📧 Sending Test Email...\n');

// Check environment variables
const emailUser = process.env.EMAIL_USER;
const emailPass = process.env.EMAIL_PASS;

if (!emailUser || !emailPass) {
    console.log('❌ Email configuration missing!');
    console.log('   EMAIL_USER:', emailUser ? '✅ Set' : '❌ Missing');
    console.log('   EMAIL_PASS:', emailPass ? '✅ Set' : '❌ Missing');
    process.exit(1);
}

async function sendTestEmail() {
    try {
        console.log('🔧 Creating email transporter...');
        
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: emailUser,
                pass: emailPass
            }
        });

        console.log('✅ Transporter created successfully');

        const testMailOptions = {
            from: emailUser,
            to: emailUser, // Send to yourself for testing
            subject: 'Test Email - Jumbled Code Password Reset',
            html: `
                <h2>Test Email - Password Reset</h2>
                <p>This is a test email to verify your email configuration is working.</p>
                <p>If you receive this email, your password reset functionality should work!</p>
                <p><strong>Test Details:</strong></p>
                <ul>
                    <li>From: ${emailUser}</li>
                    <li>To: ${emailUser}</li>
                    <li>Time: ${new Date().toLocaleString()}</li>
                </ul>
                <p>This email was sent as a test for the Jumbled Code password reset functionality.</p>
            `
        };

        console.log('📤 Sending test email...');
        console.log('   From:', emailUser);
        console.log('   To:', emailUser);
        
        const result = await transporter.sendMail(testMailOptions);
        
        console.log('✅ Test email sent successfully!');
        console.log('   Message ID:', result.messageId);
        console.log('\n🎉 Email configuration is working correctly!');
        console.log('   Check your email inbox (and spam folder) for the test email.');
        
    } catch (error) {
        console.error('\n❌ Failed to send test email:', error.message);
        
        if (error.code === 'EAUTH') {
            console.log('\n🔧 Authentication Error - Troubleshooting:');
            console.log('   1. Make sure your EMAIL_USER is correct');
            console.log('   2. Make sure your EMAIL_PASS is an app password (not your regular password)');
            console.log('   3. Enable 2-Step Verification on your Google account');
            console.log('   4. Generate an app password: https://myaccount.google.com/apppasswords');
        } else if (error.code === 'ECONNECTION') {
            console.log('\n🔧 Connection Error - Troubleshooting:');
            console.log('   1. Check your internet connection');
            console.log('   2. Make sure Gmail is accessible');
            console.log('   3. Try again in a few minutes');
        } else {
            console.log('\n🔧 General Error - Troubleshooting:');
            console.log('   1. Check your .env file configuration');
            console.log('   2. Verify your Gmail account settings');
            console.log('   3. Try with a different Gmail account');
        }
    }
}

sendTestEmail();
