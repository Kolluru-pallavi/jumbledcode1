const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const bcrypt = require('bcryptjs');

// Do not fall back to a hardcoded secret. Require configuration.
const JWT_SECRET = process.env.JWT_SECRET;

// Check if email configuration is set up
const checkEmailConfig = () => {
    const emailUser = process.env.EMAIL_USER;
    const emailPass = process.env.EMAIL_PASS;
    
    if (!emailUser || !emailPass) {
        console.error('❌ Email configuration missing:');
        console.error('   EMAIL_USER:', emailUser ? '✅ Set' : '❌ Missing');
        console.error('   EMAIL_PASS:', emailPass ? '✅ Set' : '❌ Missing');
        return false;
    }
    return true;
};

// Nodemailer Transporter
const createTransporter = () => {
    if (!checkEmailConfig()) {
        return null;
    }

    return nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });
};

// Forgot Password Route
router.post('/forgot-password', async (req, res) => {
    try {
        if (!JWT_SECRET) {
            console.error('❌ JWT_SECRET is missing. Please configure it in your .env file.');
            return res.status(500).json({ message: 'Server configuration error. Please try again later.' });
        }
        const { email } = req.body;
        
        if (!email) {
            return res.status(400).json({ message: 'Email is required' });
        }

        console.log('🔍 Looking for user with email:', email);

        const user = await User.findOne({ email });
        if (!user) {
            console.log('❌ User not found:', email);
            return res.status(400).json({ message: 'User not found' });
        }

        console.log('✅ User found:', user.email);

        const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '15m' });
        user.resetToken = token;
        // Store as a Date instance for consistency
        user.resetTokenExpiry = new Date(Date.now() + 15 * 60 * 1000);
        await user.save();

        console.log('✅ Reset token generated and saved');

        // Create reset link
        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5000}`;
        const resetLink = `${baseUrl}/reset-password.html?token=${token}`;

        console.log('🔗 Reset link created:', resetLink);
        console.log('📱 Base URL:', baseUrl);
        console.log('🔑 Token length:', token.length);
        console.log('⏰ Token expiry:', user.resetTokenExpiry);

        // Check email configuration
        const transporter = createTransporter();
        if (!transporter) {
            console.error('❌ Email transporter not created - missing configuration');
            return res.status(500).json({ message: 'Email service not configured. Please check your .env file.' });
        }

        // Send email
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: user.email,
            subject: 'Password Reset Link - Jumbled Code',
            html: `
                <h2>Password Reset Request</h2>
                <p>You requested a password reset for your Jumbled Code account.</p>
                <p>Click the link below to reset your password:</p>
                <a href="${resetLink}" style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0;">Reset Password</a>
                <p><strong>Or copy and paste this link into your browser:</strong></p>
                <p style="word-break: break-all; background-color: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 12px;">${resetLink}</p>
                <p>This link will expire in 15 minutes.</p>
                <p>If you didn't request this, please ignore this email.</p>
                <hr>
                <p style="font-size: 12px; color: #6c757d;">
                    <strong>Troubleshooting:</strong><br>
                    • If the button doesn't work, copy the link above<br>
                    • Make sure you're using a modern web browser<br>
                    • Try opening the link in a new tab/window
                </p>
            `,
            text: `Password Reset Request

You requested a password reset for your Jumbled Code account.

Click this link to reset your password: ${resetLink}

This link will expire in 15 minutes.

If you didn't request this, please ignore this email.`
        };

        console.log('📧 Attempting to send email to:', user.email);
        await transporter.sendMail(mailOptions);
        console.log('✅ Password reset email sent successfully to:', email);
        res.json({ message: 'Password reset link sent to email' });
    } catch (error) {
        console.error('❌ Forgot password error:', error);
        
        // Provide more specific error messages
        if (error.code === 'EAUTH') {
            res.status(500).json({ message: 'Email authentication failed. Please check your EMAIL_USER and EMAIL_PASS in .env file.' });
        } else if (error.code === 'ECONNECTION') {
            res.status(500).json({ message: 'Email connection failed. Please check your internet connection and email settings.' });
        } else {
            res.status(500).json({ message: 'Error sending password reset email: ' + error.message });
        }
    }
});

// Reset Password Route
router.post('/reset-password', async (req, res) => {
    try {
        if (!JWT_SECRET) {
            console.error('❌ JWT_SECRET is missing. Please configure it in your .env file.');
            return res.status(500).json({ message: 'Server configuration error. Please try again later.' });
        }
        const { token, newPassword } = req.body;

        console.log('🔄 Reset password attempt:');
        console.log('   Token length:', token ? token.length : 'missing');
        console.log('   Password provided:', !!newPassword);
        console.log('   User agent:', req.get('User-Agent'));

        if (!token || !newPassword) {
            return res.status(400).json({ message: 'Token and new password are required' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findOne({ 
            _id: decoded.id, 
            resetToken: token, 
            // Compare using Date for clarity
            resetTokenExpiry: { $gt: new Date() } 
        });

        if (!user) {
            return res.status(400).json({ message: 'Invalid or expired token' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedPassword;
        user.resetToken = undefined;
        user.resetTokenExpiry = undefined;
        await user.save();

        console.log('✅ Password reset successful for user:', user.email);
        res.json({ message: 'Password reset successful' });
    } catch (error) {
        console.error('❌ Reset password error:', error);
        if (error.name === 'TokenExpiredError') {
            return res.status(400).json({ message: 'Token has expired' });
        }
        if (error.name === 'JsonWebTokenError') {
            return res.status(400).json({ message: 'Invalid token' });
        }
        return res.status(500).json({ message: 'Error resetting password: ' + error.message });
    }
});

module.exports = router;
