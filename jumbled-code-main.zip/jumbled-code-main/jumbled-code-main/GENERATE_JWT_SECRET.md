# How to Generate a JWT Secret Key

## Method 1: Using Node.js (Recommended)

### Option A: Using crypto module in Node.js

1. **Open your terminal/command prompt**
2. **Navigate to your project directory**
3. **Run the following command:**

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

This will generate a 128-character hexadecimal string that's perfect for a JWT secret.

### Option B: Using a Node.js script

Create a file called `generate-secret.js` in your project:

```javascript
const crypto = require('crypto');
const secret = crypto.randomBytes(64).toString('hex');
console.log('Your JWT Secret Key:');
console.log(secret);
```

Then run:
```bash
node generate-secret.js
```

## Method 2: Using Online Generators

### Option A: Random.org
1. Go to https://www.random.org/strings/
2. Set length to 64
3. Choose "Hexadecimal" as the string type
4. Generate the string

### Option B: JWT.io
1. Go to https://jwt.io/
2. Look for the "Debugger" section
3. Use the "secret base64 encoded" field to generate a key

## Method 3: Using Command Line Tools

### On Windows (PowerShell):
```powershell
$bytes = New-Object Byte[] 64
(New-Object Security.Cryptography.RNGCryptoServiceProvider).GetBytes($bytes)
[System.BitConverter]::ToString($bytes) -replace '-', ''
```

### On macOS/Linux:
```bash
openssl rand -hex 64
```

## Method 4: Using Python

If you have Python installed:
```bash
python -c "import secrets; print(secrets.token_hex(64))"
```

## Recommended Approach

**Use Method 1 (Node.js crypto module)** as it's:
- ✅ Built into Node.js (no external dependencies)
- ✅ Cryptographically secure
- ✅ Generates the right length (64 bytes = 128 hex characters)
- ✅ Easy to use

## Example Generated Secret

Here's what a generated JWT secret looks like:
```
a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890
```

## How to Use the Generated Secret

1. **Copy the generated secret**
2. **Create or update your `.env` file** in the `jumbled-code-main/` directory:
   ```env
   JWT_SECRET=your-generated-secret-here
   ```
3. **Replace `your-generated-secret-here`** with the actual generated secret

## Security Best Practices

1. **Length**: Use at least 32 bytes (64 hex characters) for production
2. **Randomness**: Use cryptographically secure random generators
3. **Secrecy**: Never commit your JWT secret to version control
4. **Uniqueness**: Use different secrets for different environments (dev, staging, prod)
5. **Rotation**: Consider rotating secrets periodically in production

## Example .env File

```env
# MongoDB Connection
MONGO_URI=mongodb://localhost:27017/jumbled-code

# JWT Secret for password reset tokens (replace with your generated secret)
JWT_SECRET=a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890

# Email Configuration (Gmail)
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-16-character-app-password

# Base URL for password reset links
BASE_URL=http://localhost:5000

# Server Port
PORT=5000
```

## Verification

To verify your JWT secret is working:

1. **Start your server**: `node server.js`
2. **Check console logs**: You should see "Server is running at http://localhost:5000"
3. **Test password reset**: Try the forgot password functionality
4. **Check for errors**: Look for any JWT-related errors in the console

## Troubleshooting

### Common Issues:

1. **Secret too short**: Make sure your secret is at least 64 characters long
2. **Invalid characters**: Use only hexadecimal characters (0-9, a-f)
3. **Environment variable not loaded**: Make sure your `.env` file is in the correct location
4. **Server restart required**: Restart your server after updating the `.env` file
